-- --------------------------------------------------------
-- Servidor:                     localhost
-- Versão do servidor:           5.6.25 - MySQL Community Server (GPL)
-- OS do Servidor:               Win32
-- HeidiSQL Versão:              9.3.0.4984
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Copiando estrutura do banco de dados para curriculos
CREATE DATABASE IF NOT EXISTS `curriculos` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci */;
USE `curriculos`;


-- Copiando estrutura para tabela curriculos.account
CREATE TABLE IF NOT EXISTS `account` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` char(200) CHARACTER SET utf8 NOT NULL,
  `senha` char(8) CHARACTER SET utf8 NOT NULL,
  `data_cadastro` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `status_admin` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=latin1;

-- Copiando dados para a tabela curriculos.account: ~3 rows (aproximadamente)
/*!40000 ALTER TABLE `account` DISABLE KEYS */;
INSERT INTO `account` (`id`, `email`, `senha`, `data_cadastro`, `status_admin`) VALUES
	(21, 'joao@joao', '123456', '2016-01-07 20:31:30', 0),
	(27, 'admin@admin', '123456', '2016-01-13 12:22:44', 1),
	(28, 'teste@teste', '123456', '2016-01-14 14:50:33', 0);
/*!40000 ALTER TABLE `account` ENABLE KEYS */;


-- Copiando estrutura para tabela curriculos.dados
CREATE TABLE IF NOT EXISTS `dados` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Account_Id` int(11) NOT NULL,
  `Cargo_Pretendido` char(255) DEFAULT NULL,
  `Nome` char(50) DEFAULT NULL,
  `Sobrenome` char(255) DEFAULT NULL,
  `Data_Nascimento` char(10) DEFAULT NULL,
  `Cidade_Nascimento` char(50) DEFAULT NULL,
  `Estado_Nascimento` char(100) DEFAULT NULL,
  `Idade` char(2) DEFAULT NULL,
  `Estado_Civil` char(10) DEFAULT NULL,
  `Sexo` char(10) DEFAULT NULL,
  `N_Dependentes` char(2) DEFAULT NULL,
  `CPF` char(11) DEFAULT NULL,
  `Reservista` char(20) DEFAULT NULL,
  `RG` char(10) DEFAULT NULL,
  `Rg_Data_Emissao` char(10) DEFAULT NULL,
  `Rg_Cidade` char(150) DEFAULT NULL,
  `Rg_Estado` char(50) DEFAULT NULL,
  `Nome_Pai` char(255) DEFAULT NULL,
  `Nome_Mae` char(255) DEFAULT NULL,
  `Endereco` varchar(500) DEFAULT NULL,
  `Numero` char(30) DEFAULT NULL,
  `Bairro` char(255) DEFAULT NULL,
  `Regiao` char(20) DEFAULT NULL,
  `Cidade` char(255) DEFAULT NULL,
  `Estado` char(100) DEFAULT NULL,
  `Tel_Residencial` char(11) DEFAULT NULL,
  `Tel_Celular` char(12) DEFAULT NULL,
  `Tel_Recado` char(12) DEFAULT NULL,
  `Email` char(255) DEFAULT NULL,
  `Facebook` char(255) DEFAULT NULL,
  `Instagram` char(255) DEFAULT NULL,
  `Twitter` char(255) DEFAULT NULL,
  `Linkedin` char(255) DEFAULT NULL,
  `Ensino_Medio_Tecnico_Status` char(20) DEFAULT NULL,
  `Ensino_Medio_Tecnico_Conclusao` char(10) DEFAULT NULL,
  `Ensino_Medio_Tecnico_Instituicao` char(255) DEFAULT NULL,
  `Ensino_Medio_Tecnico_Curso` char(150) DEFAULT NULL,
  `Ensino_Superior_Possui` char(150) DEFAULT NULL,
  `Ensino_Superior_Status` char(20) DEFAULT NULL,
  `Ensino_Superior_Instituicao` char(255) DEFAULT NULL,
  `Ensino_Superior_Conclusao` char(10) DEFAULT NULL,
  `Ensino_Superior_Curso` char(150) DEFAULT NULL,
  `Ensino_Pos_Graduacao_Possui` char(150) DEFAULT NULL,
  `Ensino_Pos_Graduacao_Status` char(20) DEFAULT NULL,
  `Ensino_Pos_Graduacao_Conclusao` char(10) DEFAULT NULL,
  `Ensino_Pos_Graduacao_Instituicao` char(255) DEFAULT NULL,
  `Ensino_Pos_Graduacao_Curso` char(150) DEFAULT NULL,
  `Primeiro_Emprego` char(3) DEFAULT NULL,
  `Ultima_Empresa` char(200) DEFAULT NULL,
  `Ultima_Empresa_Cidade` char(200) DEFAULT NULL,
  `Ultima_Empresa_Salario` char(10) DEFAULT NULL,
  `Ultima_Empresa_Cargo` char(150) DEFAULT NULL,
  `Ultima_Empresa_Data_Admissao` char(10) DEFAULT NULL,
  `Ultima_Empresa_Data_Demissao` char(10) DEFAULT NULL,
  `Ultima_Empresa_Motivo_Saida` char(255) DEFAULT NULL,
  `Empresa_Anterior_Status` char(255) DEFAULT NULL,
  `Penultima_Empresa` char(150) DEFAULT NULL,
  `Penultima_Empresa_Cidade` char(200) DEFAULT NULL,
  `Penultima_Empresa_Salario` char(30) DEFAULT NULL,
  `Penultima_Empresa_Cargo` char(150) DEFAULT NULL,
  `Penultima_Empresa_Data_Admissao` char(10) DEFAULT NULL,
  `Penultima_Empresa_Data_Demissao` char(10) DEFAULT NULL,
  `Penultima_Empresa_Motivo_Saida` char(255) DEFAULT NULL,
  `Empresa_Antepenultima_Status` char(255) DEFAULT NULL,
  `Antepenultima_Empresa` char(150) DEFAULT NULL,
  `Antepenultima_Empresa_Cidade` char(200) DEFAULT NULL,
  `Antepenultima_Empresa_Salario` char(30) DEFAULT NULL,
  `Antepenultima_Empresa_Cargo` char(150) DEFAULT NULL,
  `Antepenultima_Empresa_Data_Admissao` char(10) DEFAULT NULL,
  `Antepenultima_Empresa_Data_Demissao` char(10) DEFAULT NULL,
  `Antepenultima_Empresa_Motivo_Saida` char(255) DEFAULT NULL,
  `Deficiencia` char(3) DEFAULT NULL,
  `Deficiencia_Qual` char(255) DEFAULT NULL,
  `Deficiencia_CID` char(100) DEFAULT NULL,
  `Doenca` char(3) DEFAULT NULL,
  `Doenca_Qual` char(255) DEFAULT NULL,
  `Medicamento` char(3) DEFAULT NULL,
  `Medicamento_Qual` char(255) DEFAULT NULL,
  `Fuma` char(3) DEFAULT NULL,
  `Fuma_Qtd` char(3) DEFAULT NULL,
  `Alcool` char(3) DEFAULT NULL,
  `Alcool_Quando` char(255) DEFAULT NULL,
  `Conhece_Alguem` char(3) DEFAULT NULL,
  `Grau_Parentesco` char(100) DEFAULT NULL,
  `Grau_Parentesco_Nome` char(255) DEFAULT NULL,
  `Conhecimento_Vaga` char(50) DEFAULT NULL,
  `Conhecimento_Vaga_Outros` char(255) DEFAULT NULL,
  `Questao_1` varchar(500) DEFAULT NULL,
  `Questao_2` varchar(500) DEFAULT NULL,
  `Questao_3` varchar(500) DEFAULT NULL,
  `Questao_4` varchar(500) DEFAULT NULL,
  `Questao_5` varchar(500) DEFAULT NULL,
  `Questao_6` varchar(500) DEFAULT NULL,
  `Questao_7` varchar(500) DEFAULT NULL,
  `Questao_8` varchar(500) DEFAULT NULL,
  `Questao_9` varchar(500) DEFAULT NULL,
  `Questao_10` varchar(500) DEFAULT NULL,
  `Questao_11` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;

-- Copiando dados para a tabela curriculos.dados: 1 rows
/*!40000 ALTER TABLE `dados` DISABLE KEYS */;
INSERT INTO `dados` (`Id`, `Account_Id`, `Cargo_Pretendido`, `Nome`, `Sobrenome`, `Data_Nascimento`, `Cidade_Nascimento`, `Estado_Nascimento`, `Idade`, `Estado_Civil`, `Sexo`, `N_Dependentes`, `CPF`, `Reservista`, `RG`, `Rg_Data_Emissao`, `Rg_Cidade`, `Rg_Estado`, `Nome_Pai`, `Nome_Mae`, `Endereco`, `Numero`, `Bairro`, `Regiao`, `Cidade`, `Estado`, `Tel_Residencial`, `Tel_Celular`, `Tel_Recado`, `Email`, `Facebook`, `Instagram`, `Twitter`, `Linkedin`, `Ensino_Medio_Tecnico_Status`, `Ensino_Medio_Tecnico_Conclusao`, `Ensino_Medio_Tecnico_Instituicao`, `Ensino_Medio_Tecnico_Curso`, `Ensino_Superior_Possui`, `Ensino_Superior_Status`, `Ensino_Superior_Instituicao`, `Ensino_Superior_Conclusao`, `Ensino_Superior_Curso`, `Ensino_Pos_Graduacao_Possui`, `Ensino_Pos_Graduacao_Status`, `Ensino_Pos_Graduacao_Conclusao`, `Ensino_Pos_Graduacao_Instituicao`, `Ensino_Pos_Graduacao_Curso`, `Primeiro_Emprego`, `Ultima_Empresa`, `Ultima_Empresa_Cidade`, `Ultima_Empresa_Salario`, `Ultima_Empresa_Cargo`, `Ultima_Empresa_Data_Admissao`, `Ultima_Empresa_Data_Demissao`, `Ultima_Empresa_Motivo_Saida`, `Empresa_Anterior_Status`, `Penultima_Empresa`, `Penultima_Empresa_Cidade`, `Penultima_Empresa_Salario`, `Penultima_Empresa_Cargo`, `Penultima_Empresa_Data_Admissao`, `Penultima_Empresa_Data_Demissao`, `Penultima_Empresa_Motivo_Saida`, `Empresa_Antepenultima_Status`, `Antepenultima_Empresa`, `Antepenultima_Empresa_Cidade`, `Antepenultima_Empresa_Salario`, `Antepenultima_Empresa_Cargo`, `Antepenultima_Empresa_Data_Admissao`, `Antepenultima_Empresa_Data_Demissao`, `Antepenultima_Empresa_Motivo_Saida`, `Deficiencia`, `Deficiencia_Qual`, `Deficiencia_CID`, `Doenca`, `Doenca_Qual`, `Medicamento`, `Medicamento_Qual`, `Fuma`, `Fuma_Qtd`, `Alcool`, `Alcool_Quando`, `Conhece_Alguem`, `Grau_Parentesco`, `Grau_Parentesco_Nome`, `Conhecimento_Vaga`, `Conhecimento_Vaga_Outros`, `Questao_1`, `Questao_2`, `Questao_3`, `Questao_4`, `Questao_5`, `Questao_6`, `Questao_7`, `Questao_8`, `Questao_9`, `Questao_10`, `Questao_11`) VALUES
	(12, 21, 'Analista de Suporte', 'João Paulo', 'Paulo', '15/04/1987', 'São José dos Campos', 'São Paulo', '25', 'Solteiro', 'Masculino', '0', '35582940847', '1155469797', '439295646', '12/01/2000', 'São José dos Campos', 'São Paulo', 'João Bosco de Oliveira', 'Maria Leni dos Santos Oliveira', 'Rua Colombia', '204', 'Vista Verde', 'Leste', 'São José dos Campos', 'São Paulo', '1239137183', '12991031516', '1239137183', 'tk.joaopaulo@gmail.com', 'http://www.facebook.com/joao', 'http://www.instagram.com/joao', 'http://www.twitter.com/joao', 'http://www.linkedin.com/joao', 'Completo', '03/01/2010', 'UNIVAP', 'Informárica', 'Sim', 'Completo', '03/01/2010', '03/01/2010', 'Ciencia da Computação', 'Sim', 'Completo', '01/01/2015', 'FGV', 'Administração de Empresas', 'Nao', 'Libbero', 'São José dos Campos', '00,00', 'Analista de Suporte', '01/01/2015', '13/01/2016', 'Pessoal', 'Nao', 'Teste Penultima Empresa', 'Teste Penultima Cidade', 'Teste Penultimo Salario', 'Teste Penultimo Cargo', '01/01/2015', '12/01/2016', 'Teste Penultimo Motivo', 'Nao', 'Teste Antepenultima Empresa', 'Teste Antepenultima Cidade', 'Teste Antepenultimo Salario', 'Teste Antepenultimo Cargo', '01/01/2015', '25/01/2016', 'Teste Antepenultimo Motivo', 'Sim', 'Teste Deficiencia Qual', 'Teste Cid', 'Sim', 'Teste Doença', 'Sim', 'Teste Medicamento', 'Sim', 'Tes', 'Sim', 'Teste alcool', 'Sim', 'Teste Grau Parentesco', 'Teste nome da pessoa parentesco', 'Outros', 'Teste Vaga Outros', 'Teste Questao 1', 'Teste Questao 2', 'Teste Questao 3', 'Teste Questao 4', 'Teste Questao 5', 'Teste Questao 6', 'Teste Questao 7', 'Teste Questao 8', 'Teste Questao 9', 'Teste Questao 10', 'Teste Questao 11');
/*!40000 ALTER TABLE `dados` ENABLE KEYS */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
